export const environment = {
    production: false,
    domain: 'http://192.168.1.44:9005'
};
