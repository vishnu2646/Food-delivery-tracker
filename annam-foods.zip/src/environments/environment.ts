export const environment = {
    production: true,
    domain: 'http://annamservice.revampapps.com',
};
