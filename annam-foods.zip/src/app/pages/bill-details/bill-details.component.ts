import { CommonModule, Location } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { FormsModule } from '@angular/forms';
import { PaymentReviewComponent } from "../payment-review/payment-review.component";

import { DropdownModule } from 'primeng/dropdown';
import { lastValueFrom } from 'rxjs';

import { ApiService, UserdetailsService } from '../../services';
import { ErrorComponent } from '../../components/error/error.component';

@Component({
    selector: 'app-bill-details',
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        PaymentReviewComponent,
        DropdownModule,
        ErrorComponent
    ],
    templateUrl: './bill-details.component.html',
    styleUrl: './bill-details.component.css'
})
export class BillDetailsComponent implements OnInit {
    private location = inject(Location);

    private activatedRoute = inject(ActivatedRoute);

    private apiService = inject(ApiService);

    private userDetailsService = inject(UserdetailsService);

    public showErrorDialog: boolean = false;

    public emptyMessage: String = '';

    private loggedInData: any;

    private otp: String = '';

    private dhId: number = 0;

    public bill: IBill = {} as IBill;

    public edit_status: boolean = false;

    public selected_status: { code: number; name: String; }[] | undefined;

    public selected_payment_mode: { code: number; mode: String; }[] | undefined;

    private seqId: number = 0;

    public options: any[] | undefined;

    public paymentOptions: any[] | undefined;

    public isEditMode: Record<EditModeFields, boolean> = {
        DeliveryTimeRemark: false,
        selected_status: false,
        selected_payment_mode: false,
        PaidAmount: false,
        TransactionNo: false
    };

    public updateBill = {
        DeliveryStatus: 0,
        Paymode: 'Not Paid',
        TransactionNo: '',
        DeliveryTimeRemark: '',
        PaidAmount: 0,
    }

    public ngOnInit(): void {
        window.scroll(0, 0);

        this.options = [
            { code: 0, status: 'Not deliveried' },
            { code: 1, status: 'Delivery Done' },
            { code: 2, status: 'Hold' },
        ];
        
        this.paymentOptions = [
            { code: 0, mode: 'Cash' },
            { code: 1, mode: 'UPI' },
        ];

        this.getSequenceNumberParam();
        this.getBillDetail();
    }

    public getSequenceNumberParam(): void {
        this.activatedRoute.paramMap.subscribe(param => {
            this.seqId = Number(param.get('id'));
        });

        this.userDetailsService.isLoggedIn$.subscribe(_data => {
            this.loggedInData = { 
                isLoggedIn: this.userDetailsService.isLoggedIn(),
                otp: this.userDetailsService.userData.otp,
                loginData: this.userDetailsService.userData.loginData,
            }
            
            this.otp = this.loggedInData.otp.otp;
            this.dhId = this.loggedInData.loginData.CheckLoginjs.Table[0].DhId;
        });
    }

    public async getBillDetail() {
        try {
            const response = await lastValueFrom(this.apiService.getIndividualBillDetail(this.dhId, this.otp, this.seqId))
            if(response && response.IndividualBillDetailsjs.Table.length > 0) {
                this.bill = response.IndividualBillDetailsjs.Table[0];
                this.updateBill = {
                    DeliveryTimeRemark: String(this.bill.DeliveryTimeRemark) === null ? '' : String(this.bill.DeliveryTimeRemark),
                    Paymode: String(this.bill.Paymode) || '',
                    PaidAmount: Number(this.bill.PaidAmount) || 0,
                    TransactionNo: String(this.bill.TransactionNo) || '',
                    DeliveryStatus: this.bill.DeliveryStatus === 0 ? 0 : this.bill.DeliveryStatus === 1 ? 1 : 2
                }
            } else {
                this.bill = {} as IBill;
                if(response.billListjs.Table[0].ErrStatus === "Invalid OTP or Closed Session") {
                    this.showErrorDialog = !this.showErrorDialog;
                    this.emptyMessage = response.billListjs.Table[0].ErrStatus;
                }
            }
        } catch (error) {
            console.log("detial error");
            console.log("error", error);
            this.showErrorDialog = true;
            this.emptyMessage = 'Something went wrong!... <br/> please login again...'
        }
    }

    public toggleEditMode(field: EditModeFields) {
        this.isEditMode[field] = !this.isEditMode[field];
    }

    public editStatus(event: any) {
        this.updateBill.DeliveryStatus = event.target.value;
        this.toggleEditMode('selected_status');
    }

    public editPaymentMode(event: any) {
        // const eventData = event;
        // const mode = eventData.value.mode;
        this.updateBill.Paymode = event.target.value;
        this.toggleEditMode('selected_payment_mode');
    }

    public async makePayment() {

        try {
            const updateBillData = { DhId: this.dhId, OTP: this.otp, SeqId: this.seqId, ...this.updateBill };
            console.log(updateBillData);
            
            const response = await lastValueFrom(this.apiService.updateBill(updateBillData));

            if(response === "Bill Updated Successfully.") {
                alert(response);
                this.location.back();
            }
            
        } catch (err) {
            console.log(err);
        }
    }
}

interface IBill {
    ErrNo: String;
    SeqId: number,
    DhId: number,
    Cpid: number,
    InvNo: String;
    InvDate: Date;
    Vid: number,
    Vcode: String;
    VName: String;
    ItemDesc: String;
    BillAddress: String;
    DelAddress: String;
    Area: String;
    Dpid: number,
    DeliveryPerson: String;
    NoOfItems: number,
    Subtotal: number,
    Taxtotal: number,
    NetTotal: number,
    DeliveryRemark: String | null,
    Balance: number,
    BalanceUpto: String | null,
    Paymode: String;
    TransactionNo: number;
    PaidAmount: number;
    PaidDateTime: Date;
    Paidby: String;
    GPSloc: String | null;
    DeliveryStatus: number;
    DeliveryTimeRemark: String | null;
}

type EditModeFields = 'DeliveryTimeRemark' | 'selected_status' | 'selected_payment_mode' | 'PaidAmount' | 'TransactionNo';