import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { count } from 'rxjs';
import { ICheckLogin } from '../../types';
import { UserdetailsService } from '../../services/userdetials/userdetails.service';
import { isDefinedAndNotEmpty } from '../../utils/utils';
import { CommonModule } from '@angular/common';
import { ErrorComponent } from '../../components/error/error.component';

@Component({
    selector: 'app-home',
    standalone: true,
    imports: [
        CommonModule,
        ErrorComponent
    ],
    templateUrl: './home.component.html',
    styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
    private router = inject(Router);

    private userDetailsService = inject(UserdetailsService);

    public loggedInData: any;

    public cardData: IHomeData = {} as IHomeData;

    public data: Idata[] = [
        {
            title: 'No of Bills',
            navigateTo: 'noofBills',
            count: 0,
        },
        {
            title: 'Delivered Bills',
            navigateTo: 'deliveredBills',
            count: 0,
        },
        {
            title: 'Balance Bills',
            navigateTo: 'balanceBills',
            count: 0,
        },
        {
            title: 'Total Amount',
            navigateTo: '',
            count: 0
        },
        {
            title: 'Collection Amount',
            navigateTo: '',
            count: 0
        }
    ]

    public showErrorDialog: boolean = false;

    public emptyMessage: String = '';

    public ngOnInit(): void {

        this.userDetailsService.refreshData$.subscribe(() => {
            this.getLogedInData();
        });

        this.getLogedInData();
    }

    public getLogedInData() {
        this.userDetailsService.isLoggedIn$.subscribe(_data => {
            this.loggedInData = { 
                isLoggedIn: this.userDetailsService.isLoggedIn(),
                otp: this.userDetailsService.userData.otp,
                loginData: this.userDetailsService.userData.loginData,
            }
        });

        if(isDefinedAndNotEmpty(this.loggedInData.loginData)) {
            console.log(this.data);
            this.data.forEach((data) => {
                if(data.title === 'Balance Bills') {
                    data.count = this.loggedInData.loginData.CheckLoginjs.Table[0].BalanceBills;
                } else if(data.title === 'Total Amount') {
                    data.count = this.loggedInData.loginData.CheckLoginjs.Table[0].Totalvalue;
                } else if(data.title === 'No of Bills') {
                    data.count = this.loggedInData.loginData.CheckLoginjs.Table[0].NoOfBills
                } else if(data.title === 'Delivered Bills') { 
                    data.count = this.loggedInData.loginData.CheckLoginjs.Table[0].NoOfBills - this.loggedInData.loginData.CheckLoginjs.Table[0].BalanceBills;
                } 
            });
        } else {
            this.showErrorDialog = true;
            this.emptyMessage = 'Something went wrong!... <br/> please login again...'
        }
    }

    public nagiateTo(nagiateTo: String) {
        this.router.navigate(['/dashboard/bills', nagiateTo]);
    }
}

interface IHomeData {
    Actiondate: Date;
    Balance: number;
    BalanceBills: number;
    CashReceipt: number;
    DhId: number;
    DpName: String;
    Dpid: number;
    ErrNo: String;
    Expense: number;
    FinishTime: Date | null;
    Itemtype: String;
    NoOfBills: number;
    StartTime: Date | null;
    Totalvalue: number;
    TripStatus: String;
    Tripid: number;
    VehicleNo: number | null | String;
    VhId: number | null | String;
}

interface Idata {
    title: String;
    navigateTo: String;
    count: number;
}