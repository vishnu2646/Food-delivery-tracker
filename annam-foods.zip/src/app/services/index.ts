import { ApiService } from "./api/api.service";
import { UserdetailsService } from "./userdetials/userdetails.service";

export {
    ApiService,
    UserdetailsService,
}